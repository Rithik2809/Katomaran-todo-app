const express = require('express');
const router = express.Router();

router.get('/', (req, res) => {
  res.json([{ title: "Sample Task", description: "This is a sample task." }]);
});

module.exports = router;